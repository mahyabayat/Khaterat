<?php $__env->startSection('content'); ?>
<div class="container">
    
        <?php echo csrf_field(); ?>
        <div class="row"> 
        <div class="col-8 offset-2">
             
               
                
                  <div class="row " style="padding-left:280px;padding-bottom:20px">
                  <a href="/p/create"  class="btn btn-info" role="button"> 
                            + ثبت خاطره جدید</a>
                 
                  </div>
          <div style="padding-left:410px" >
                  <div class="" style="background-color:white;height:80px;width:500px;padding-top:20px;padding-left:410px">
                  عنوان خاطره 

                  </div></div>
         </div>
    </div>
    <div class="row pt-4">
         <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 pb-4">
     
        <div style="padding-left:410px" >
                  <div class="" style="background-color:white;height:80px;width:500px;padding-top:20px;padding-left:410px">
                  <?php echo e($post->$title); ?>  

                  </div>
                  </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\node-project\resources\views/home.blade.php ENDPATH**/ ?>